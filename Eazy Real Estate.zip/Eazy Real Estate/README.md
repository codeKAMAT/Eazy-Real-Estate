# BT-Real-Estate

Real estate django web app.

## Get started

I recommend you install packages using `pipenv`.

To get started run the following in the root directory:

```sh
pipenv shell
pipenv install
python manage.py runserver
```

You will also need a `.env` file in the `/btre` directory. This should contain an `EMAIL` field, and a `PASSWORD` field.